// Select DOM elements
const valueElement = document.querySelector('.value');
const incrementButton = document.querySelector('.increment');
const decrementButton = document.querySelector('.decrement');
const resetButton = document.querySelector('.reset');
const stepInput = document.querySelector('.step');

// Initialize the counter value
let counterValue = 0;

// Function to update the displayed value
function updateValue() {
    valueElement.textContent = counterValue;
}

// Increment button click event
incrementButton.addEventListener('click', () => {
    const step = parseInt(stepInput.value) || 1; // Get step value or default to 1
    counterValue += step;
    updateValue();
});

// Decrement button click event
decrementButton.addEventListener('click', () => {
    const step = parseInt(stepInput.value) || 1; // Get step value or default to 1
    counterValue -= step;
    updateValue();
});

// Reset button click event
resetButton.addEventListener('click', () => {
    counterValue = 0; // Reset counter to 0
    updateValue();
});
